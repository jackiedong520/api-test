"""
第一步：读取excel中用例
第二步：根据用例发送请求
第三步：校验结果
第四步：将测试结果、返回报文写入excel
"""
import xlrd,requests,os
from xlutils import copy
from comm.log import atp_log
import datetime
now=now_time = datetime.datetime.now()
timestamp = datetime.datetime.strftime(now,"%Y%m%d%H%M%S%f")[:-3]#获取时间精确到毫秒

class OpCase(object):
    def get_case(self,start_nrows,end_nrows,file_path):
        cases= []   #定义一个列表存放所有的cases
        if file_path.endswith('.xls') or file_path.endswith('.xlsx'):
            try:
                book = xlrd.open_workbook(file_path)
                sheet = book.sheet_by_index(0)#读取excel的第一个sheet表
                self.file_path = file_path   #因为该函数已经传了参数路径，为方便write_excel引用，在此实例化
                for i in range(start_nrows,end_nrows):
                    row_data = sheet.row_values(i)   #获取的每一行数据存到列表row_data
                    cases.append(row_data[2:6])#读取第3到第6列数据
                atp_log.info('共读取%s条用例'%(end_nrows-start_nrows))
            except Exception as e:
                atp_log.error('[%s]用例获取失败，错误信息：%s'%(file_path,e))
        else:
            atp_log.error('用例文件不合法，%s'%file_path)
        return cases
    def my_request(self,url,method,data,headers):
        try:
            if method.upper() == 'POST':
                res = requests.post(url, data,headers)
            elif method.uper() == 'GET':
                res = requests.get(url, params=data).text
            else:
                atp_log.warning('该请求方式暂不支持')
                res = '该请求方式暂不支持'
        except Exception as e:
            msg = '【%s】接口调用失败，%s'%(url,e)
            atp_log.error(msg)
            res = msg
        return res
    def dataToDict(self,data):  #把数据转成字典。
        res = {}
        data = data.split(',')
        for d in data:  #
            k, v = d.split('=')
            res[k] = v
    def check_res(self,res,check):  #res:实际结果，check：预期结果
        for c in check.split(','):#判断code值是否在返回的response里面
            if c not in res:
                atp_log.info('结果校验失败，预期结果：【%s】，实际结果【%s】'%(c,res))
                return '失败'
            return '通过'
    def write_excel(self,start_nrows,case_res):
        book = xlrd.open_workbook(self.file_path)
        new_book = copy.copy(book)
        sheet = new_book.get_sheet(0)
        row = start_nrows
        for case_case in case_res:
            sheet.write(row,7,case_case[0])
            sheet.write(row,8,case_case[1])
            row += 1
        new_book.save(self.file_path.replace('xlsx','xls'))


