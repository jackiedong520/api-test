import datetime,os
sign='ED85892F818AD8EE22580DC08CADB5C9'

now=now_time = datetime.datetime.now()
timestamp = datetime.datetime.strftime(now,"%Y%m%d%H%M%S%f")[:-3]
#登录接口
test_host='http://10.0.40.232:8380'
BASE_PATH = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   #三层目录定位到ATP目录
MAIL_HOST = 'smtp.qq.com'
MAIL_USER='747948100@qq.com'#发件人邮箱
MAIL_PASSWRD = 'mppegchmvtszbfjd'#发件邮箱授权码
TO = ['747948100@qq.com']#收件人邮箱

LEVEL = 'debug' #设置日志默认级别

LOG_PATH = os.path.join(BASE_PATH,'log')   #日志文件在logs目录下
LOG_NAME = 'atp_log'    #设置日志文件名
CASE_PATH = os.path.join(BASE_PATH,'data') #用例文件在cases目录下
report_path=os.path.join(BASE_PATH,'report')
appKey='sundata.mumu.andriod'


