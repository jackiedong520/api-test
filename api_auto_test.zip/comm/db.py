import cx_Oracle
def select_psw(key,table_name,condition):
    con = cx_Oracle.connect('bigdatatest', 'bigdatatest123', '10.0.40.240:1521/ORCL')  # 创建连接
    cursor = con.cursor()  # 创建游标
    sql='select '+ key +' from '+ table_name +' where '+ condition
    cursor.execute(sql)  #执行sql语句
    psw = cursor.fetchone()[0]
    return psw
    cursor.close()  #关闭游标
    con.close()     #关闭数据库连接

select_psw('password','BAS_USER',"USER_NO='283478'")