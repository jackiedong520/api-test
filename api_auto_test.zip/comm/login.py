import xlrd,requests
from comm import db

abs_path = r'D:\work\SDJY\api_auto_test\data\api_testcase.xls'
book = xlrd.open_workbook(abs_path)
sheet = book.sheet_by_index(1)
#老师账号登录数据读取
th_rowdata = sheet.row_values(1)  # 获取的第2行数据存到列表row_data
th_url = th_rowdata[2] # 获取的第2行第3列数据存为url
th_method = th_rowdata[3]# 获取的第2行第4列数据存为method
th_USER_NO = th_rowdata[4]# 获取的第2行第5列数据存为USER_NO
th_check = th_rowdata[5]# 获取的第2行第6列数据存为check

th_userKey=th_USER_NO[9:15]
th_psw=db.select_psw(key='password',table_name='BAS_USER',condition=th_USER_NO)
th_data={'userKey':th_userKey,'userPassword':th_psw}

#学生账号登录数据读取
st_rowdata = sheet.row_values(2)  # 获取的第3行数据存到列表row_data
st_url = st_rowdata[2] # 获取的第2行第3列数据存为url
st_method = st_rowdata[3]# 获取的第2行第4列数据存为method
st_USER_NO = st_rowdata[4]# 获取的第2行第5列数据存为USER_NO
st_check = st_rowdata[5]# 获取的第2行第6列数据存为check

st_userKey=st_USER_NO[9:15]
st_psw=db.select_psw(key='password',table_name='BAS_USER',condition=st_USER_NO)
st_data={'userKey':st_userKey,'userPassword':st_psw}

def teacher_login():
    res=requests.post(url=th_url,data=th_data,headers = {"Content-Type": "application/x-www-form-urlencoded"})
    a=res.json()['data']['identity'].keys()#获取identity的字典
    identity= list(a)[0]#通过list将字典中的keys转化为列表
    token=res.json()['data']['token']
    teacherId=res.json()['data']['uid']

    return identity,token,teacherId
def student_login():
    res=requests.post(url=st_url,data=st_data,headers = {"Content-Type": "application/x-www-form-urlencoded"})
    return res
teacher_login()
student_login()