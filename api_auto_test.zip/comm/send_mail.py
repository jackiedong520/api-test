import yagmail
from comm import config
from comm.log import atp_log
def sendmail(title,content,attrs=None):
    m = yagmail.SMTP(host=config.MAIL_HOST,user=config.MAIL_USER,password=config.MAIL_PASSWRD,smtp_ssl=True)
    m.send(to=config.TO,subject=title,contents = content,attachments = attrs)
    atp_log.info('发送邮件完成')