import time, sys
sys.path.append('./testcase')
from HTMLTestRunner import  HTMLTestRunner
import unittest
# 指定测试用例为当前文件夹下的目录
test_dir = './testcase'
discover = unittest.defaultTestLoader.discover(test_dir, pattern='*test*.py')
if __name__ == "__main__":
    now = time.strftime("%Y-%m-%d %H_%M_%S")
    filename = './report/' + now + '_result.html'
    fp = open(filename, 'wb')
    runner = HTMLTestRunner(stream=fp,title='Guest Manage System Interface Test Report',description='Implementation Example with:')
    runner.run(discover)
    fp.close()
