# encoding: utf-8
import datetime,os
from comm import config
now=now_time = datetime.datetime.now()
day = datetime.datetime.strftime(now,"%Y%m%d%H%M%S%f")[:-3]
print(day)


abs_path =os.listdir(os.path.join(config.CASE_PATH))
print(abs_path)

for f in os.listdir(config.CASE_PATH):  # 每次循环的时候读一个excel
    abc_path = os.path.join(config.CASE_PATH, f)
    print(abc_path)