import requests
url='http://58.19.173.84:8097/v1/user/message/unread/count'
data={"userId":"2009271025280001","terminal":"web"}
headers = {"Content-Type": "application/json"}

res=requests.post(url=url,data=data,headers=headers)
a=res.text
print(res)
print(a)
