import os,sys
BASE_PATH = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0,BASE_PATH)

from comm.common import OpCase
from comm import config
start_nrows=5#登录测试用例开始的行
end_nrows=6#登录测试用例结束的行
class Test_GetVersion(object):
    def find_case(self):
        op = OpCase()
        for f in os.listdir(config.CASE_PATH):  # 每次循环的时候读一个excel
            abs_path = os.path.join(config.CASE_PATH, f)
            case_list = op.get_case(start_nrows,end_nrows,abs_path)
            res_list = []
            for case in case_list:  # 循环每一个excel里面的所有用例
                url, method, req_data, check = case
                headers = {"Content-Type": "application/x-www-form-urlencoded"}  # 不传Content-Type,data的格式就不对，请求响应就不对
                res = op.my_request(url, method, req_data,headers)  # 调用完接口返回的结果
                status = op.check_res(res.text, check)
                res_list.append([res.text, status])
            op.write_excel(start_nrows,res_list)

Test_GetVersion().find_case()