import os,sys,xlrd
BASE_PATH = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0,BASE_PATH)

from comm.common import OpCase
from comm.send_mail import sendmail
from comm import config
start_nrows=1#登录测试用例开始的行
class TestLogin(object):
    def find_case(self):
        op = OpCase()
        for f in os.listdir(config.CASE_PATH):  # 每次循环的时候读一个excel
            abs_path = os.path.join(config.CASE_PATH, f)
            book = xlrd.open_workbook(abs_path)
            sheet = book.sheet_by_index(0)
            case_list = op.get_case(start_nrows, sheet.nrows, abs_path)
            results = []
            for i in range(1, sheet.nrows):#循环读取result列存储到results列表
                row_result = sheet.row_values(i)  # 获取的每一行数据存到row_result
                results.append(row_result[8:9])  # 读取第9列数据
            pass_count, fail_count = 0, 0
            for result in results:#根据result列结果判断通过的用例数
                if result == ['通过']:
                    pass_count += 1
                else:
                    fail_count += 1
            msg = '''
                各位好，
                    本次自动化接口测试共运行%s条用例，通过%s条，失败%s条。
                ''' % (len(results), pass_count, fail_count)
            sendmail('测试用例运行结果', content=msg, attrs=abs_path)

TestLogin().find_case()
